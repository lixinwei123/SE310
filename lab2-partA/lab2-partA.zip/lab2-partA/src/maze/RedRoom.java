package maze;

import java.awt.*;

class RedRoom extends Room {
    private Integer num;

    RedRoom(Integer num){
        super(num);
        this.num = num;
    }

    @Override
    public Color getColor() {
        return super.getColor();
    }

}
