//Written by Kevin Li
//See read me for more information on different classes use
import menu.Menu1;

public class Main {
    public static void main(String[] args){
      Menu1 startMenu = new Menu1();
      startMenu.loadMenuItems();
    }
}
